package S_DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginReadWrite1 {
	
	static ArrayList<LoginData1> al ;
	
	public static ArrayList<LoginData1> readExcel() {
		
		al = new ArrayList<LoginData1>();
		
		try {
			
			File f = new File("login_test.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb  = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			int first_row = sh.getFirstRowNum();
			int last_row = sh.getLastRowNum();
			
			for(int i=1;i<=last_row-first_row;i++) {
				LoginData1 ld = new LoginData1();
				XSSFRow rw = sh.getRow(i);
				XSSFCell c = rw.getCell(0);
				ld.uid = c.getStringCellValue();
				XSSFCell c1 = rw.getCell(1);
				ld.pswd = c1.getStringCellValue();
				XSSFCell c2 = rw.getCell(2);
				ld.ex_res = c2.getStringCellValue();
				
				if(ld.ex_res.equals("FAILURE")) {
					XSSFCell c3 = rw.getCell(3);
					ld.ex_err1 = c3.getStringCellValue();
					XSSFCell c4 = rw.getCell(4);
					ld.ex_err2 = c4.getStringCellValue();
					
				}
				
				al.add(ld);
				
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return al;
	}
	
	public static LoginData1 login(LoginData1 l) {
	       System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
	       WebDriver dr = new ChromeDriver();
	       dr.get("http://demowebshop.tricentis.com/");
	       
	       dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	       dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(l.uid);
	       dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(l.pswd);
	       dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	       
	       String ss = dr.getTitle();
	       if(ss.contains("Login"))
	    	   l.ac_res = "FAILURE";
	       else
	    	   l.ac_res = "SUCCESS";
	       
	       if(l.ac_res.equals("FAILURE")) {
//	    	  l.ac_err1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
//	    	  l.ac_err2 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
//	       
//	    	  if(l.ac_res.equals(l.ex_res) && l.ac_err1.equals(l.ex_err1) && l.ac_err2.equals(l.ex_err2))
//		    	   l.test_res = "PASS";
//		       else
//		    	   l.test_res = "FAIL";
	    	   if(l.ex_res.equals(l.ac_res)) {
	    		   l.test_res = "PASS";
	    	   }
	       }
	       else {
	    	   if(l.ex_res.equals(l.ac_res)) {
	    		   l.test_res = "PASS";
	    	   }
	       }
	      
	       
	    	   
	       dr.close();
	       return l;
	       
	}
	
	public static void excelWrite() {
		
			try {
				
				File f = new File("login_test.xlsx");
				FileInputStream fis = new FileInputStream(f);
				XSSFWorkbook wb  = new XSSFWorkbook(fis);
				XSSFSheet sh = wb.getSheet("Sheet1");
				int row=1;
				for(LoginData1 v:al) {
					XSSFRow rw = sh.getRow(row);
					if(v.ex_res.equals("FAILURE")) {
						XSSFCell c1 = rw.createCell(6);
						c1.setCellValue(v.ac_err1);
						XSSFCell c2 = rw.createCell(7);
						c2.setCellValue(v.ac_err2);
							
					}
					XSSFCell c = rw.createCell(5);
					c.setCellValue(v.ac_res);
					XSSFCell c3 = rw.createCell(8);
					c3.setCellValue(v.test_res);
					
					row++;
				}
				
				FileOutputStream fos = new FileOutputStream(f);
				wb.write(fos);
				
				
				
				
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		
		
	}

	public static void main(String args[]) {
		    int row=0;
			ArrayList<LoginData1> data = readExcel();
			for(LoginData1 val:data) {
				LoginData1 ld1 = login(val);
				al.set(row, ld1);
				row++;
			}
			excelWrite();
		
		
		
	}

	
}
