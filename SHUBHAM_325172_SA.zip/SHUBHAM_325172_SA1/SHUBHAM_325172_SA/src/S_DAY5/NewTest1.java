package S_DAY5;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewTest1 {
	
 @BeforeMethod
 public void BM() {
	 System.out.println("BM");
 }
 
 @AfterMethod
 public void AF() {
	 System.out.println("AM");
 }
	
  @Test
  public void a() {
	  System.out.println("In test f");
  }
  @Test
  public void b() {
	  System.out.println("In test f1");
  }
  @Test
  public void c() {
	  System.out.println("In test f2");
  }
}
