package Assignment_27_oct_2019;

public class Student {
	int rollno;
	String name;
	int java,selenium;
	float avg;
	public void average() {
		this.avg = (this.java + this.selenium)/2.0f;
		if(this.avg > 65)
			this.display();
	}
	public Student(int rollno,String name,int java,int selenium) {
		this.rollno = rollno;
		this.name = name;
		this.java = java;
		this.selenium = selenium;
		this.average();
	}
	public void display() {
		System.out.println(this.rollno+"  "+this.name+"  "+this.java+"  "+this.selenium+"  "+this.avg);
		
	}
	public static void main(String args[]) {
		Student s1 = new Student(101,"Shubham",90,81);
		Student s2 = new Student(101,"Rakesh",78,87);
		Student s3 = new Student(101,"Aayush",67,70);
	}

}
