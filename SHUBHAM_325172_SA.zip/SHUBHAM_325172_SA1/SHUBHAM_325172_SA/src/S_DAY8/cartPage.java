package S_DAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class cartPage {
	
	String xpath1 = "//*[@id=\'cart_contents_container\']/div/div[1]/div["; // value 3,4,5 and so on
    String xpath2 = "]\"";
    
    WebDriver dr;
    
    public cartPage(WebDriver dr) {
    	this.dr = dr;
    	PageFactory.initElements(dr, this);
    }
    
    public String verify() {
     	String res = dr.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
    	return res;
    }
    
}
