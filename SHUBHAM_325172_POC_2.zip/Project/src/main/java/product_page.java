package main.java;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class product_page {
	 WebDriver dr;
		public product_page(WebDriver dr) {
			this.dr=dr;
		}
		
		public int click_rate() {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/div[1]/div/div[1]/div/section[6]/div[2]/div/div[1]/div/div/label")).click();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String rating = dr.findElement(By.xpath("//*[@id=\"productRating_LSTACCFERKJBGDSQP7CCAI0PP_ACCFERKJBGDSQP7C_\"]/div")).getText();
			int r = Integer.parseInt(rating);
			return r;
	
		}
		
		public int price_range() {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			WebElement wel=dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/div[1]/div/div[1]/div/section[2]/div[4]/div[3]/select"));
			Select sel=new Select(wel);
			sel.selectByValue("1500");
			String price = dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/div[2]/div[2]/div/div[1]/div/a[3]/div/div[1]")).getText();
			price = price.substring(1);
			int itemPrice = Integer.parseInt(price);
			return itemPrice;
			
		}
		
		public String click_item() {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String name = dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div[1]/div[2]/div[2]/div/div[1]/div/a[2]")).getText();
			dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div[1]/div[2]/div[2]/div/div[1]/div")).click();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ArrayList<String> tabs2 = new ArrayList<String> (dr.getWindowHandles());
		    dr.switchTo().window(tabs2.get(1));
			return name;
		}
		
		/*public void add_to_cart() {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/div[2]/div[2]/div/div[1]/div")).click();
		}*/

}
