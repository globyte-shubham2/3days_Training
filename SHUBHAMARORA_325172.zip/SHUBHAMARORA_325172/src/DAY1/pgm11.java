package DAY1;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=2,b=5,c=8;
		if(a>b && a>c) {
			System.out.println("a is largest");
			if(b>c) {
				System.out.println("c is smallest");
			}
			else {
				System.out.println("b is smallest");
			}
		}
			
		else if(b>a && b>c) {
			System.out.println("b is largest");
			if(a>c)
				System.out.println("c is smallest");
			else
				System.out.println("a is smallest");
		}
			
		else {
			System.out.println("c is largest");
			if(a>b)
				System.out.println("b is smallest");
			else
				System.out.println("a is smallest");
		} 
			

	}

}
