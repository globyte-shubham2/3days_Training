package main.java;


import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class cart_page {
	WebDriver dr;
	public cart_page(WebDriver dr) {
			this.dr=dr;
	}
		
	public void add_to_cart1() {
		/*ArrayList<String> tabs2 = new ArrayList<String> (dr.getWindowHandles());
	    dr.switchTo().window(tabs2.get(1));*/
	    try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    dr.findElement(By.xpath("//*[text()='ADD TO CART']")).click();    
	 }
}
