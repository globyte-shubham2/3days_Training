package S_DAY8;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class testCart {
	
	login_page lg;
	home_page hp;
	cartPage cp;
	
	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr =new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		lg = new login_page(dr);
		hp = new home_page(dr);
		cp = new cartPage(dr);
		lg.do_login("standard_user", "secret_sauce");
		
	}
	
	@Test(dataProvider = "cart")
	public void addItems(String xp,String name) {
		hp.addToCartButton(1);
		hp.clickCart();
		String ac = cp.verify();
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(ac, name);
		sa.assertAll();
	}
	
	@DataProvider(name="cart")
	public String[][] provideData() {
		String str[][] = {{"//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button","Sauce Labs Backpack"}
				
		};
		return str;
	}

}
