package DAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import DAY3.student;

public class pgm1 {
	
	public ArrayList<student> readExcel() {
		
		ArrayList<student> ar_st = new ArrayList<student>();
		int start,end;
		try {
			File f = new File("C:\\Users\\shubham.arora2\\Book1.xlsx");
			FileInputStream fis= new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			start = sh.getFirstRowNum();
			end = sh.getLastRowNum();
			int traverse = end - start + 1;
			
			for(int i=1;i<traverse;i++) 
			{
				student s = new student();
			XSSFRow r = sh.getRow(i);
			
			XSSFCell c = r.getCell(0);
            s.rollno = (int) c.getNumericCellValue();
            
            XSSFCell c1 = r.getCell(1);
            s.name = c1.getStringCellValue();
            
            XSSFCell c2 = r.getCell(2);
            s.m1 = (int) c2.getNumericCellValue();
            
            XSSFCell c3 = r.getCell(3);
            s.m2 = (int)c3.getNumericCellValue();
            
            s.average();
            System.out.println(s.avg);
            ar_st.add(s);
            System.out.println(ar_st.get(i-1).avg);
            
            
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		for(student shubham:ar_st) {
			System.out.println(shubham.name+ "   "+shubham.avg);
		}
		System.out.println(ar_st.get(1).name);
		return ar_st;

	}
	
	public void writeExcel(ArrayList<student> s) {
		int row=1;
		try {
			File f = new File("C:\\Users\\shubham.arora2\\Book1.xlsx");
			FileInputStream fis= new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			
			for(student s1:s) {
				System.out.println(s1.avg);
				XSSFRow r = sh.getRow(row);
				XSSFCell c = r.createCell(4);
				c.setCellValue((double) s1.avg);
				row++;
				FileOutputStream fos = new FileOutputStream(f);
				wb.write(fos);
			}
			
//			FileOutputStream fos = new FileOutputStream(f);
//			wb.write(fos);
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}

		
	}

}

