package main.java;
import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readExcel {
	
	 public Object[][] readData() {
		  String data[][]=null;
		 
		  try {
			File f = new File("FB_POC.xlsx");  
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			int firstRow = sh.getFirstRowNum();
			int lastRow = sh.getLastRowNum();
			int rowCount = (lastRow-firstRow)+1;
			data = new String[rowCount][5];
			for(int row = 1;row<rowCount;row++) {
				XSSFRow rw = sh.getRow(row);
				for(int column = 0;column<5;column++) {

					XSSFCell c = rw.getCell(column);
					data[row-1][column] = c.getStringCellValue();
					System.out.print(data[row-1][column]+"    ");
				}
				System.out.println();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  return data;
	  }


}
