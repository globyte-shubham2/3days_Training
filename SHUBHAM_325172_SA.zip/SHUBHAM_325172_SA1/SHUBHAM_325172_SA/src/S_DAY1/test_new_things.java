package S_DAY1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class test_new_things {
	
	public static void main(String args[]) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver driver = new ChromeDriver();
		for(int i=0;i<3;i++)
		driver.get("http://www.google.com");
		
//		String currWindowHandleStr = driver.getWindowHandle();
//		System.out.println("Current windowhandler before create tab : " + currWindowHandleStr);
//		

	
		  
		  
		
		
 
	}
	

}
