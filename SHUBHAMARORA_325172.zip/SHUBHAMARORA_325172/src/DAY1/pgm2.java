package DAY1;
import java.util.*;
public class pgm2 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a number");
		int num=in.nextInt();
		int n=num;
		int r=0,rev=0;
		while(n!=0) {
			r=n%10;
			rev=rev*10+r;
			n=n/10;
		}
		if(num==rev)
			System.out.println("Palindrome");
		else
			System.out.println("Not a Palindrome");
	}

}
