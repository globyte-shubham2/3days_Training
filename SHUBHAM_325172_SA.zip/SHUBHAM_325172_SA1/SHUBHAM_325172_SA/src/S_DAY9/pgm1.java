package S_DAY9;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class pgm1 {
	// HUB program
	
	WebDriver dr;
	String autURL, nodeURL;
	
	@BeforeClass
	public void setup()throws MalformedURLException
	{
		autURL = "https://www.facebook.com";
		nodeURL = "http://192.168.43.194:5566/wd/hub";
		DesiredCapabilities cap = DesiredCapabilities.firefox();
		cap.setBrowserName("firefox");
		cap.setPlatform(Platform.WINDOWS);
		dr = new RemoteWebDriver(new URL(nodeURL),cap);
	}
	
	@Test
	public void t1() {
		dr.get("https://www.facebook.com");
	}

}
