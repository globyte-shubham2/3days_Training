package DAY2;

public class pgm11 {
	public static boolean isPrime(int n) {
		int c=0;
		for(int i=2;i<=n/2;i++) {
			if(n%i==0)
				c=1;
		}
		if(c==0) {

			System.out.println(n+" is prime number");
			return true;
		}
		else 
			return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=1;int num=2;
		while(n<=10) {
			boolean op=isPrime(num);
			if(op==true)
			n++;
			num++;
		}

	}

}
