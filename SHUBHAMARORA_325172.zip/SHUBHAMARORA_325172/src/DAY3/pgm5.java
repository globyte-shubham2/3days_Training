package DAY3;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="I am learning java";
		int p=0;
		for(int i=0;i<s1.length();i++) {
			if(s1.charAt(i)==' ')
				p++;
		}
		System.out.println(++p);

	}

}
