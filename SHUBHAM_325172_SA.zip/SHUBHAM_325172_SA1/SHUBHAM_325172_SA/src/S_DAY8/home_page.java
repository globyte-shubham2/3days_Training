package S_DAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class home_page {
	
	WebDriver dr=null;	
	String addToCart1 = "//div[@class='inventory_item'][";
	String addToCart2 = "]//button";
	
	public home_page(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
	
	public void addToCartButton(int itemNo) {

		dr.findElement(By.xpath(this.addToCart1+itemNo+this.addToCart2)).click();
	}
	
	public void clickCart() {
		dr.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a")).click();
	}

}
