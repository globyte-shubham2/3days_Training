/**
 * 
 */
package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * @author shubham.arora2
 *
 */
public class pgm3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			File f = new File("C:\\Users\\shubham.arora2\\Book1.xlsx");
			FileInputStream fis= new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
//			XSSFRow r = sh.getRow(2);
//			XSSFCell c = r.getCell(0);
//			XSSFCell c = r.createCell(1);
			
			XSSFRow r = sh.createRow(3);
			XSSFCell c = r.createCell(0);
			
			String s = c.getStringCellValue();
			int a = (int)c.getNumericCellValue();
			System.out.println(s);
			
			
			FileOutputStream fos = new FileOutputStream(f);
			c.setCellValue("python");
			wb.write(fos);
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

}
