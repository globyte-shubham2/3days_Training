package S_DAY10;

import org.testng.annotations.Test;

public class parallel2 {
  @Test
  public void t1() {
	  System.out.println("In t1 - start");
	  try {
		  Thread.sleep(5000);
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  System.out.println("In t1 - end");
  }
  
  @Test
  public void t2() {
	  System.out.println("In t2 - start");
	  try {
		  Thread.sleep(5000);
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  System.out.println("In t2 - end");
  }
}
