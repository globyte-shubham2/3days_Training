package Assignment_27_oct_2019;

public class birds {
	int nol;
	String color;
	String food;
	String name;
	String gender;
	int age;
	
	public void flys() {
		System.out.println("The Bird Flys\n");
	}
	public void eats() {
		System.out.println("The Bird eats\n");
	}
	public void walks() {
		System.out.println("Birds walk\n");
	}
	public void display() {
		System.out.println("No of legs: " +this.nol+"\nSkin color: "+ this.color + "\nFood: " + this.food + "\nName: "+this.name + "\nGender: " + this.gender + "\nAge: " + this.age );
		walks();
	}

}
