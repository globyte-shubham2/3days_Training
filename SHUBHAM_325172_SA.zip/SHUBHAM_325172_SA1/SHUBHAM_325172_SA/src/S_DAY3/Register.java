package S_DAY3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Register {
	
	public static void main(String args[]) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
		if(dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).isSelected()) {}
		else {
			dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
		}
		dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys("Shubham");
		dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys("Arora");
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("shubham.xyz@kiet.edu");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("p0o9i8u7y6");
		dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys("p0o9i8u7y6");
		dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
		String str = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	    if(str.equals("shubham.xyz@kiet.edu"))
	    	System.out.println("Register success");
	    else
	    	System.out.println("Register Unsuccessful");
	}

}
