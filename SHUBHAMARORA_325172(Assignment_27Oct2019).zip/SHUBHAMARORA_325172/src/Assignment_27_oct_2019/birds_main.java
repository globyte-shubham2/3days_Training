package Assignment_27_oct_2019;

public class birds_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parrot p1 = new parrot(18,30,80,"Red","Fruits","Female","Cockatoo",2);
		parrot p2 = new parrot(62,48,40,"Yellow","Seeds","Male","Strigopidae",2);
		parrot p3 = new parrot(8,22,20,"Maroon","Insects","Female","Macaw",2);
		owl o1 = new owl(29,60,3,"White","Squirrels","Female","Eostrix",2);
		owl o2= new owl(17,30,4,"Black","Insects","Male","True owl",2);
		
		p1.display();
		p1.eats();
		p1.flys();
		p2.display();
		p2.simulate();
		p2.flys();
		p3.display();
		p3.eats();
		p3.shouts();
		
		o1.display();
		o1.eats();
		o1.neck_rotate();
		o1.vision();
		o2.display();
		o2.hunts();

	}

}
