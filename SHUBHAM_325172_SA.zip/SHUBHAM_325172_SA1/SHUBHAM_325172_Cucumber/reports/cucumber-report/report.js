$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "AUT Login",
  "description": "",
  "id": "aut-login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "To verify login for valid data",
  "description": "",
  "id": "aut-login;to-verify-login-for-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "USer enters login details",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "Home page is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 10442244700,
  "status": "passed"
});
formatter.match({
  "location": "test1.user_enters_login_details()"
});
formatter.result({
  "duration": 4033777800,
  "status": "passed"
});
formatter.match({
  "location": "test1.home_page_is_displayed()"
});
formatter.result({
  "duration": 36709900,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "To verify login for Invalid data",
  "description": "",
  "id": "aut-login;to-verify-login-for-invalid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "User enters invalid login details",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "Home page is not displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 9434802500,
  "status": "passed"
});
formatter.match({
  "location": "test2.user_enters_invalid_login_details()"
});
formatter.result({
  "duration": 931183300,
  "status": "passed"
});
formatter.match({
  "location": "test2.home_page_is_not_displayed()"
});
formatter.result({
  "duration": 29595900,
  "error_message": "java.lang.AssertionError: The following asserts failed:\n\texpected [shubham.1510150@kiet.edu] but found [Register]\r\n\tat org.testng.asserts.SoftAssert.assertAll(SoftAssert.java:43)\r\n\tat STEP_DEF.test2.home_page_is_not_displayed(test2.java:29)\r\n\tat ✽.Then Home page is not displayed(a.feature:11)\r\n",
  "status": "failed"
});
});