package S_DAY6;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class pgm4 {
  
	@Test(dataProvider = "security")
  public void login(String u,String p) {
	  System.out.println("login : "+u+ "  "+p );
  }
  
	@DataProvider(name = "security")
	public String[][] getdata(){
		String[][] data = {{"uid1","pass1"},
				{"uid2","pass2"}
		};
		return data;
	}
}
