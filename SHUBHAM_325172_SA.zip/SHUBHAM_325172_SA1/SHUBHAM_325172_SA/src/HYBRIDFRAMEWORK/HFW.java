package HYBRIDFRAMEWORK;

import java.io.IOException;

public class HFW extends excel_read{
	
//	static Logger log;
	static String email;
	static keyword_sh d = new keyword_sh();
	static tc_selection td = new tc_selection();
	static String filename = "Hybrid.xlsx";
	
	public static void main(String args[]) {
		keywordMethods all_methods = new keywordMethods();
		String id,ch,testdata = null;
		int i,j,k=0;
		for(i=1;i<=3;i++) {
			td = read_TC_SELECTION_SH(i);
			System.out.println(td.flag);
			if(td.flag.equals("Y")) {
				for(j=1;j<20;j++) {
					try {
						d = read_kw_sh(j);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println(d.TC_ID);
					if(d.TC_ID.equals(td.tcid)) {
						System.out.println("Yes");
						break;
					}else
						continue;
				}
				
				get_test_data(td.test_data_sh,2,2);
				
				for(login_test_data data:td_al) {
					for(k=j;k<=((j+td.no_steps)-1);k++) {
						if(k==(j+2)) {testdata = data.uid;email = testdata;}
						if(k==(j+3)) {testdata = data.pwd;}
						try {
							d= excel_read.read_kw_sh(k);System.out.println("arora :  "+d.Keyword+d.XPath);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						ch = d.Keyword;
						System.out.println("testdata:  "+ testdata);
						switch(ch) {
						case "launchchrome":System.out.println("shubham: "+d.Test_Data);
							all_methods.launchChrome(d.Test_Data);
						break;
						case "click_link":all_methods.clickLink(d.XPath);
						break;
						case "enter_txt":all_methods.enterText(d.XPath,testdata);
						break;
						case "click_btn":all_methods.clickButton(d.XPath);
						break;
						case "verify":all_methods.verify(d.XPath,email);
						break;
						}
						
					}
				}
			}
		}
	}
	

}
