package DAY7;


import java.util.ArrayList;

import DAY3.student;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		pgm1 excel=new pgm1();
		
		
			   ArrayList<student> s1 = excel.readExcel();
			   for(student s:s1) {
				   System.out.println(s.name);
			   }
			   
			   excel.writeExcel(s1);
	}

}
