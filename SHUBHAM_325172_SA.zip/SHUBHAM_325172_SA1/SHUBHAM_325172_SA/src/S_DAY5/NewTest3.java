package S_DAY5;

import org.testng.annotations.Test;

import S_DAY4.LoginData;
import S_DAY4.LoginReadWrite;

public class NewTest3 {
	
	@Test
	public void fun1() {
		LoginReadWrite rw = new LoginReadWrite();
		LoginData ld = new LoginData();
	    ld.uid = "shubham.xyz@kiet.edu";
	    ld.pswd = "p0o9i8u7y6";
	    ld.ex_res = "SUCCESS";
	    LoginData ob = rw.login(ld);
	    System.out.println(ob.ac_res);
	}

}
