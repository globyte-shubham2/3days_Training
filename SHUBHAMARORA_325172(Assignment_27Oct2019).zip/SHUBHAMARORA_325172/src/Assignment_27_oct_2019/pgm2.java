package Assignment_27_oct_2019;

import java.util.*;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Please Enter a Number");
        Scanner in  = new Scanner(System.in);
        int number = in.nextInt();
        int temp = number;
        int r,sum=0;
        while(temp!=0) {
        	r = temp%10;
        	sum += Math.pow(r, 3) ;
        	temp /= 10; 
        }
        if(number == sum)
        	System.out.println(number +" is an armstrong number");
        else
        	System.out.println(number +" is not an armstrong number");
	}

}
