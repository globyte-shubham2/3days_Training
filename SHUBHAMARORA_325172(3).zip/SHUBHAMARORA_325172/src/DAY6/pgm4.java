package DAY6;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Elephant e1 = new Elephant(7,6);
		Elephant e2 = new Elephant(6,5);
		Tiger t1 = new Tiger(6,7);
		Tiger t2 = new Tiger(7,9);
		
		e1.age=30;
		e1.color="Dark brown";
		e1.food="Grasses";
		e1.gender="male";
		e1.name=" Raju";
		e1.nol=4;
		e1.display();
		e1.eats();
		e1.swim();
		
		
		e2.age=36;
		e2.color="Black";
		e2.food="vegetables";
		e2.gender="male";
		e2.name="ramu";
		e2.nol=4;
		e2.display();
		e2.eats();
		e2.swim();
		e2.runs();
		e2.acts();
		
		t1.age=24;
		t1.color="Golden yellow";
		t1.food="Dogs";
		t1.gender="male";
		t1.name="lion king";
		t1.display();
		t1.climb();
		t1.eats();
		t1.mauls();
		t1.roar();
		
		t2.age=26;
		t2.color="Pale yellow";
		t2.food="animals";
		t2.gender="male";
		t2.name="boro";
		t1.display();
		t2.climb();
		t2.eats();
		t2.mauls();
		t2.roar();
		t2.runs();
		

		
		
		
		
		
		
		


}
}