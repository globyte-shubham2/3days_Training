package Assignment_27_oct_2019;

import java.util.ArrayList;

public class pgm5 {
	
	public static ArrayList<String> get_each_word(String str){
		ArrayList<String> s = new ArrayList<String>();
		String st = str.replace(",","");
		st += " ";
		String temp="";
		for(int i=0;i<st.length();i++) {
			if(st.charAt(i) == ' ') {
				s.add(temp);
				temp = "";
			}else {
				temp +=st.charAt(i);
			}
				
		}
		return s;
		
	}
	
	public static ArrayList<String> count_vowels(ArrayList<String> s){
		ArrayList<String> ss = new ArrayList<String>();
		for(String sc:s) {
			int vowel=0;
			for(int i=0;i<sc.length();i++) {
				if(sc.charAt(i)=='a'|| sc.charAt(i)=='A'||sc.charAt(i)=='e'||sc.charAt(i)=='E'||sc.charAt(i)=='i'||sc.charAt(i)=='I'||sc.charAt(i)=='o'||sc.charAt(i)=='O'||sc.charAt(i)=='u'||sc.charAt(i)=='U') {
					vowel++;
				}
			}
			if(vowel>2)
				ss.add(sc);
		}
		return ss;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String str = "I have learnt loops, oops concepts, Inheritance, exception handling, arraylist and string handling";
        ArrayList<String> s = get_each_word(str);
        ArrayList<String> s1 = count_vowels(s);
        for(String sn:s1)
        	System.out.println(sn);
	}

}
