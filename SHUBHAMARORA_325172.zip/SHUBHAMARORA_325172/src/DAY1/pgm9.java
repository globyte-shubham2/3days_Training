package DAY1;

public class pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		if(a>b)
			System.out.println("a is greater than b");
		else if(a<b)
			System.out.println("a is less than b");
		else
			System.out.println("a equal b");

	}

}
