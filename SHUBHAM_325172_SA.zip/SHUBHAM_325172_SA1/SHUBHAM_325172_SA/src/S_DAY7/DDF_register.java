package S_DAY7;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DDF_register {
	
	@Test(dataProvider="register")
	public void receiveData() {
		
	}
	
	@DataProvider(name="register")
	public void excel_data() {
		
	}

}
