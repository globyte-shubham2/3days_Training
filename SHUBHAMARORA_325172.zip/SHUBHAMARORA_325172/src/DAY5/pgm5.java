package DAY5;

import DAY3.student;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r1 = 1;
		pgm4 excel=new pgm4();
		
		for(int i=1;i<5;i++) {
			   student s1 = excel.readExcel(i);
			   s1.average();
			   excel.writeExcel(s1,i);
			}
//		student s1=excel.readExcel();
//		s1.average();
//		excel.writeExcel(s1);
		
		

	}

}
