package S_DAY3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
// this program contains errors just for reference

public class pgm1 {
	// prg to click and validate user actions
	// from the url link https://ultimateqa.com/simple-html-elements-for-automation/
	
	public static void main(String args[]) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://ultimateqa.com/simple-html-elements-for-automation/");
        
           
//		boolean br = dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[8]/div/div/div/form/input[1]")).isSelected();
//        if(br==false)
//           dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[8]/div/div/div/form/input[1]")).click();
//	      
        
        
//		dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[2]/div/div[3]/div/div/div/div/form/button")).click();
//		String str = dr.findElement(By.xpath("//*[@id=\"post-4690\"]/div[1]/h1")).getText();
//		if(str.equals("Button success"))
//			System.out.println("Button click success");
//		else
//			System.out.println("button click unsuccessful");
		
    	
        
        dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[10]/ul/li[1]/a")).click();
        dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[10]/ul/li[2]/a")).click();
        
        
	}
	

}
