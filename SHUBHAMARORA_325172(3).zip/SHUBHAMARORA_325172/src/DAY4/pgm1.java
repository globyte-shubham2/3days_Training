package DAY4;
import java.util.*;
public class pgm1 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.println("Enter number of rows");
		int row=in.nextInt();
		for(int i=1;i<=row;i++) {
        	for(int j=row;j>i;j--)
        		System.out.print(" ");
        	for(int k=1;k<=i;k++)
        		System.out.print("*");
        	for(int l=1;l<i;l++)
        		System.out.print("*");
        	System.out.println();
        }
	}

}



