package Assignment_27_oct_2019;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = {23,44,84,37,91,18};
		int sum = 0;
		for(int i=0;i<arr.length;i+=2) {
			if(arr[i]%2 != 0)
				sum += arr[i];
		}
		System.out.println("sum is: "+sum);

	}

}
