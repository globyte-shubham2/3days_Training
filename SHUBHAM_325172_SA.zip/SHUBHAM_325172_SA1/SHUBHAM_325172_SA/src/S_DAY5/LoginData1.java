package S_DAY5;

public class LoginData1 {
	public String uid,pswd,ex_res,ex_err1,ex_err2,ac_res,ac_err1,ac_err2,test_res;

}
