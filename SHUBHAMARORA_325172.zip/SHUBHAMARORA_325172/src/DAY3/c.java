package DAY3;

public class c {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		b b1=new b();
		b1.abc=10;
		b1.xyz=20;
		b1.show1();
		b1.show2();

	}

}
