package DAY6;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> ar = new ArrayList<String>();
		
		ar.add("shubham");
		ar.add("arora");
		System.out.println(ar);
		ar.add(2,"globallogic");
		System.out.println(ar);
		ar.remove("shubham");
		System.out.println(ar);

	}

}
