package POM1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class cart_page {

	WebDriver dr;
	
	cart_page(WebDriver dr){
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public String verify() {
		String s=dr.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
		return s;
	}
}
