package S_DAY6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import S_DAY5.LoginData1;
import S_DAY5.LoginReadWrite1;

public class pgm3 {
  @Test
  public void f1() {
	  LoginData1 ld = new LoginData1();
	  LoginReadWrite1 rw = new LoginReadWrite1();
	  ld.uid = "shubham.1510150@kiet.edu";
	  ld.pswd = "p0o9i8u7y6";
	  ld.ex_res = "SUCCESS";
	  
	  LoginData1 ld1 = rw.login(ld);
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(ld1.ex_res, ld1.ac_res);
	  sa.assertAll();
	  System.out.println("In f1");
	  
  }
  @Test
  public void f2() {
	  LoginData1 ld = new LoginData1();
	  LoginReadWrite1 rw = new LoginReadWrite1();
	  ld.uid = "shubham.1510150@kiet.edu";
	  ld.pswd = "p0o9i8u7yfsd";
	  ld.ex_res = "SUCCESS";
	  ld.ex_err1 = "Login was unsuccessful. Please correct the errors and try again.";
	  ld.ex_err2 = "The credentials provided are incorrect";
	  
	  LoginData1 ld1 = rw.login(ld);
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(ld1.ex_res, ld1.ac_res);
	  
	  System.out.println("In f2");
	  sa.assertAll();
	  
  }
}
