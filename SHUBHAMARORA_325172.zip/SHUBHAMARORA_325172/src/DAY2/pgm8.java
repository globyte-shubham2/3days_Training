package DAY2;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int start=16;
		int sum=0;
		while(start<75) {
			if(start%7==0)
				sum+=start;
			start++;
		}
		System.out.println(sum);

	}

	
}
