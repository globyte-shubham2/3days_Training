package Assignment_27_oct_2019;

import java.util.ArrayList;

public class pgm1 {
	public static void main(String args[]) {
		ArrayList<Integer> al = new ArrayList<Integer>();
	for(int iterate=10;iterate<=30;iterate++) {
		if(iterate%2==0) 
			al.add(iterate);
	}
	for(int i=0;i<al.size();i++)
		System.out.println(al.get(i));
	}
}
