package main.java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class login_page {
	
	static WebDriver dr;
	static By xuname=By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input");
    static By xpwd=By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input");
    static By btn=By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[3]/button");
    
    public login_page(WebDriver dr) {
    	this.dr=dr;
    }
    
    public static void enter_username(String uid) {
    	dr.findElement(xuname).sendKeys(uid);  
    }
    
    public static void enter_password(String up) {
    	dr.findElement(xpwd).sendKeys(up);  
    }
    
    public static void click_btn() {
    	dr.findElement(btn).click();  
    }
    
    public String login(String uid,String pwd) {
    	this.enter_username(uid);
    	this.enter_password(pwd);
    	this.click_btn();
    	try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	String uname = dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[3]/div/div/div/div")).getText();
    	return uname;
    }
    
    public String get_loginpage_title() {
    	return dr.getTitle();  
    }
    

}
