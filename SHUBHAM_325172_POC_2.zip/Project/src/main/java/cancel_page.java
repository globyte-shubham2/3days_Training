package main.java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class cancel_page {
	WebDriver dr;
	public cancel_page(WebDriver dr) {
		this.dr=dr;
	}
	public void cancel() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/button[1]")).click();
		//dr.switchTo().alert().accept();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/div/div/div[3]/div[1]/div[3]/div[2]/div[1]/span/span")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement wel=dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[4]/div[1]/div[1]/div/div/div/div[1]/div[2]/div/select"));
		Select sel=new Select(wel);
		sel.selectByValue("purchased_mistake");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[4]/div[1]/div[1]/div/div/div/div[3]/button")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[4]/div[1]/div[2]/div/div/div/div/div/div/button")).click();
	}
	

}
