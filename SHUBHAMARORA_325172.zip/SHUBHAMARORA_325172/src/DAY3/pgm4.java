package DAY3;

public class pgm4 {
	public static void rowMax(int a,int b,int c,int d,int index) {
		index++;
		if(a>b && a>c && a>d)
			System.out.println("Row"+index+" max : "+a);
		else if(b>a && b>c && b>d)
			System.out.println("Row"+index+" max : "+b);
		else if(c>a && c>b && c>d)
			System.out.println("Row"+index+" max : "+c);
		else 
			System.out.println("Row"+index+" max : "+d);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int m[][]= {{1,2,30,4},{51,6,7,8},{45,65,55,87}};
		for(int i=0;i<3;i++) {
			for(int j=0;j<4;j++)
				System.out.print(m[i][j]+" ");
			System.out.println();
		}
		for(int k=0;k<3;k++) {
			rowMax(m[k][0],m[k][1],m[k][2],m[k][3],k);
		}

	}

}
