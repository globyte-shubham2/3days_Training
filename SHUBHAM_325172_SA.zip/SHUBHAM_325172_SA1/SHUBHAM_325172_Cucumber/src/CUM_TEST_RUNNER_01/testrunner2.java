package CUM_TEST_RUNNER_01;

import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="FEATURES",glue="STEP_DEF",plugin="html:reports/cucumber-report")
public class testrunner2 extends AbstractTestNGCucumberTests {
 
}
