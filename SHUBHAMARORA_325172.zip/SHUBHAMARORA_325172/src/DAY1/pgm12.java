package DAY1;
import java.util.*;
public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		int sub1,sub2,sub3;
		System.out.println("Enter 3 subjects marks");
		sub1=in.nextInt();
		sub2=in.nextInt();
		sub3=in.nextInt();
		int student_class;
		student_class=(sub1+sub2+sub3)/3;
		if(student_class>=60)
			System.out.println("First class");
		else if(student_class>=50 && student_class<60)
			System.out.println("Second class");
		else if(student_class>=35 && student_class<=50)
			System.out.println("Pass class");
		else if(student_class<35)
			System.out.println("Fail");
	}

}
