package S_DAY6;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operations {
	
	public String read_excel(int row,int col) {
		String temp="";
		try {

			File f = new File("KeyDataDriven1.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb  = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
		    XSSFRow rw = sh.getRow(row);
		    XSSFCell c = rw.getCell(col);
		    temp = c.getStringCellValue();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return temp;
	}

}
