package CUM_TEST_RUNNER_01;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="FEATURES",glue="STEP_DEF",tags = "@ROUND2")
public class TestTags extends AbstractTestNGCucumberTests {
 
}
