package CUM_STEP_DEF_01;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	
	public static WebDriver dr;
	
	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr =new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com/login");
		System.out.println("Login page is displayed");
	}

	@When("^USer enters login details$")
	public void user_enters_login_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		System.out.println("USer enters login details");
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("shubham.1510150@kiet.edu");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("p0o9i8u7y6");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	}

	@Then("^Home page is displayed$")
	public void home_page_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		String str = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(str, "shubham.1510150@kiet.edu");
		sa.assertAll();
		System.out.println("Home page is displayed");
	}
	
	


}
