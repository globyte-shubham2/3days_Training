package S_DAY3;

public class LoginData {
	String uid;
	String pass;
	String exp,act,res;
	

}
