package Assignment_10Nov;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class pgm1_register {
	WebDriver dr;
	String mail;
	
	@Test(dataProvider = "regis")
  public void register(String gender,String f_name,String l_name,String id,String pass,String c_pass) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
		dr.findElement(By.xpath(gender)).click();
		dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(f_name);
		dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(l_name);
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(id);
		mail = id;
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(pass);
		dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(c_pass);
		dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
		test1();
		
		
  }
	
	public void test1() {
	 String id = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	 SoftAssert sa = new SoftAssert();
	 sa.assertEquals(id,mail);
	 System.out.println("Expected Result :"+mail);
	 System.out.println("Actual Result :"+id);
	 sa.assertAll();
	}
	
	@DataProvider(name = "regis")
	public String[][] provide_data() {
		String[][] str = {{"//*[@id=\"gender-male\"]","shubham","arora","shubham.15@gmail.com","123456","123456"},
				{"//*[@id=\"gender-male\"]","shubham","arora","shubham.16@gmail.com","123456","123456"}
				};
		return str;
	}
}
