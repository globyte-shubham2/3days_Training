package CUM_STEP_DEF_01;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
	
	WebDriver dr=null;
	
	@When("^User enters invalid login details$")
	public void user_enters_invalid_login_details() throws Throwable {
		
		dr = test1.dr;
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("shubham.1510150@kiet.edu");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("p0o9i87y6");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	    System.out.println("User enters invalid login details");
	}

	@Then("^Home page is not displayed$")
	public void home_page_is_not_displayed() throws Throwable {
		String str = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(str, "shubham.1510150@kiet.edu");
		sa.assertAll();
		System.out.println("Home page is displayed");
	    
	}

}
