package S_DAY4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginReadWrite {
	
	static ArrayList<LoginData> al ;
	
	public static LoginData readExcel(int i) {
		al = new ArrayList<LoginData>();
		LoginData ld = new LoginData();
		try {
			
			File f = new File("login_test.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb  = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
				
				
				XSSFRow rw = sh.getRow(i);
				XSSFCell c = rw.getCell(0);
				ld.uid = c.getStringCellValue();
				XSSFCell c1 = rw.getCell(1);
				ld.pswd = c1.getStringCellValue();
				XSSFCell c2 = rw.getCell(2);
				ld.ex_res = c2.getStringCellValue();
				
				if(ld.ex_res.equals("FAILURE")) {
					XSSFCell c3 = rw.getCell(3);
					ld.ex_err1 = c3.getStringCellValue();
					XSSFCell c4 = rw.getCell(4);
					ld.ex_err2 = c4.getStringCellValue();
					
				}
				
				al.add(ld);
				
			
			
			
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return ld;
	}
	
	public static LoginData login(LoginData l) {
	       System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
	       WebDriver dr = new ChromeDriver();
	       dr.get("http://demowebshop.tricentis.com/");
	       
	       dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	       dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(l.uid);
	       dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(l.pswd);
	       dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	       
	       String ss = dr.getTitle();
	       if(ss.contains("Login"))
	    	   l.ac_res = "FAILURE";
	       else
	    	   l.ac_res = "SUCCESS";
	       
	       if(l.ac_res.equals("FAILURE")) {
	    	  l.ac_err1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
	    	  l.ac_err2 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
	       
	    	  if(l.ac_res.equals(l.ex_res) && l.ac_err1.equals(l.ex_err1) && l.ac_err2.equals(l.ex_err2))
		    	   l.test_res = "PASS";
		       else
		    	   l.test_res = "FAIL";
	       }
	       else {
	    	   if(l.ex_res.equals(l.ac_res)) {
	    		   l.test_res = "PASS";
	    	   }
	       }
	      
	       
	    	   
	       al.set(0,l); //COMMENT THIS IN CASE OF CALLING FROM NewTest3.java //Login test usnig TestNg
//	       dr.close();
	       return l;
	       
	}
	
	public static void excelWrite(boolean br,int i) {
		if(br) {
			try {
				
				File f = new File("login_test.xlsx");
				FileInputStream fis = new FileInputStream(f);
				XSSFWorkbook wb  = new XSSFWorkbook(fis);
				XSSFSheet sh = wb.getSheet("Sheet1");
				XSSFRow rw = sh.getRow(i);
				if(al.get(0).ex_res.equals("FAILURE")) {
					XSSFCell c1 = rw.createCell(6);
					c1.setCellValue(al.get(0).ac_err1);
					XSSFCell c2 = rw.createCell(7);
					c2.setCellValue(al.get(0).ac_err2);
						
				}
				XSSFCell c = rw.createCell(5);
				c.setCellValue(al.get(0).ac_res);
				XSSFCell c3 = rw.createCell(8);
				c3.setCellValue(al.get(0).test_res);
				FileOutputStream fos = new FileOutputStream(f);
				wb.write(fos);
				
				
				
				
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
	}

	public static void main(String args[]) {
		for(int i=1;i<=4;i++) {
			LoginData data = readExcel(i);	
			login(data); 
			excelWrite(true,i);
		}
		
		
	}

	
}
