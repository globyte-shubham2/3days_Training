package package1;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import main.java.*;
public class NewTest1 {
	  login_page lp;
	  home_page hp;
	  cart_page cp;
	  product_page pp;
	  WebDriver dr;
	  placeorder po;
	  cancel_page cp1;
	  readExcel re;
	  SoftAssert sa;
	  String itemName;
	  
	  @BeforeClass
	  public void bc() {
		  System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		  dr=new ChromeDriver();
		  dr.get("https://www.Flipkart.com");
		  dr.manage().window().maximize();
		  lp=new login_page(dr);
		  hp=new home_page(dr);
		  cp=new cart_page(dr);
		  pp=new product_page(dr);
		  po=new placeorder(dr);
		  cp1=new cancel_page(dr);
		  re=new readExcel();
		 
	  }
	  
	  @Test
	  public void readData() {
		  re.readData();
	  }
	  
	 /* @Test(priority=0) 
	  public void testLogin() {
		  String uname = lp.login("9540455907","p0o9i8u7y6");
		  sa = new SoftAssert();
		  sa.assertEquals(uname, "Shubham");
		  sa.assertAll();	
		  
	  }
	  
	  @Test(priority=1)
	  public void searchItem() {
		 String exItem = hp.search();
		 String actualItem = dr.getTitle();
		 sa.assertEquals(exItem, actualItem);
		 sa.assertAll();
	  }
	  
	  @Test(priority=2)
	  public void itemRating() {
		  int rating = pp.click_rate();
		  if(rating >= 4)
		      sa.assertEquals("success", "success");
		  else
			  sa.assertEquals(String.valueOf(rating), "4 or above");
		  sa.assertAll();
	  }
	  
	  @Test(priority=3)
	  public void itemRange() {
		  int price = pp.price_range();
		  if(price<1500) {
			  sa.assertEquals("success", "success");
			  sa.assertAll();
		  }
		  else {
			  sa.assertEquals("failure", "success");
			  sa.assertAll();
		  }
	  }
	  
	  @Test(priority=4)
	  public void clickItem() {
		  itemName = pp.click_item();
		  String actualName = dr.getTitle();
		  if(actualName.contains(itemName))
			  actualName = itemName;
		  sa.assertEquals(actualName,itemName);
		  sa.assertAll();
	  }
	  
	  @Test(priority=5)
	  public void addToCart() {
		  cp.add_to_cart1();
		  try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  String actualName = dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div[2]/div/div[1]/div/div[2]/div/div[1]/div[1]/div[1]")).getText();
		  sa.assertEquals(actualName,itemName);
		  sa.assertAll();
	  }
	  
	  @Test(priority=6)
	  public void placeOrder() {
		  po.placeorder1();
		  po.delivery();
		  try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  String actualName = dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/div/div/div[3]/div[1]/div[1]/div/div[2]/a")).getText();
		  sa.assertEquals(actualName,itemName);
		  sa.assertAll();
	  }
	  
	  @Test(priority=7)
	  public void cancelOrder() {
		  cp1.cancel();
		  try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  String orderStatus = dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/span/div[4]/div[1]/div[2]/div/div[2]/div[1]/span")).getText();
		  sa.assertEquals("Cancelled",orderStatus);
		  sa.assertAll();
	  }*/
	  
	 
	 	  
	 /* @Test
	  public void t() {
		  lp.login("9540455907","p0o9i8u7y6");
		  hp.search();
		  pp.click_rate();
//		  pp.add_to_cart();
      String hnd=dr.getWindowHandle();
      for(String handle:dr.getWindowHandles()) {
    	  dr.switchTo().window(handle);
      }
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		    ArrayList<String> tabs2 = new ArrayList<String> (dr.getWindowHandles());
		    dr.switchTo().window(tabs2.get(0));
		  cp.add_to_cart1();
		  po.placeorder1();
		  po.delivery();
		  cp1.cancel();
		  hp.click_cart();
		 String s= cp.verify();
		 System.out.println(s);	
		 SoftAssert sa=new SoftAssert();
			sa.assertEquals(s,"");
			sa.assertAll();
	  }*/
 
}
