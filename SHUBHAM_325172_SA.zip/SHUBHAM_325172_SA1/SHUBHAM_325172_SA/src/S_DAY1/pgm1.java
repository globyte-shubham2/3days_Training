package S_DAY1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
		
//		String title = dr.getTitle();
//		System.out.println("title : "+title);
//		
//		List rb = dr.findElements(By.name("sex"));
//		((WebElement)rb.get(1)).click();
		
		dr.findElement(By.id("email")).sendKeys("shubhamarora9540@gmail.com");
		dr.findElement(By.id("pass")).sendKeys("32504820120");
		dr.findElement(By.id("u_0_b")).click();
		
		String str = dr.findElement(By.className("_1vp5")).getText();
		if(str.equalsIgnoreCase("Shubham"))
			System.out.println("Login Success");
		else
			System.out.println("Login Unsuccessful");
		
//		WebElement we1 = dr.findElement(By.id("day")); /* Select the element in a dropdown */
//		Select sel1 = new Select(we1);
//		sel1.selectByVisibleText("13");
//		
//		WebElement we2 = dr.findElement(By.id("month"));
//		Select sel2 = new Select(we2);
//		sel2.selectByVisibleText("Jan");
//		
//		WebElement we3 = dr.findElement(By.id("year"));
//		Select sel3 = new Select(we3);
//		sel3.selectByVisibleText("1997");
//		
		
		

	}

}
