package S_DAY6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import S_DAY5.LoginData1;
import S_DAY5.LoginReadWrite1;

public class pgm5 {
    
	LoginData1 ld;
	LoginData1 ld1;
	LoginReadWrite1 rw;
	
	@BeforeClass
	public void setValue() {
		ld = new LoginData1();
		ld1 = new LoginData1();
		rw = new LoginReadWrite1();
	}
	
	
	@Test(dataProvider = "demo_login")
  public void login(String u,String p,String res) {
		ld.uid = u;
		ld.pswd = p;
		ld.ex_res = res;
		ld1 = rw.login(ld);
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(ld1.ex_res, ld1.ac_res);
	  sa.assertAll();
  }
  
	@DataProvider(name = "demo_login")
	public String[][] getdata(){
		String[][] data = {{"shubham.1510150@kiet.edu","p0o9i8u7y6","SUCCESS"},
				{"shubham.1510150@kiet.edu","wgejyd","FAILURE"}
				
		};
		return data;
	}
}
