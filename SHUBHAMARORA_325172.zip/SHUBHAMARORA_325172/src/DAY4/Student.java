package DAY4;

public class Student {
	int rollno;
	String name;
	int m1;
	int m2;
	float avg;
	public void display() {
		System.out.println("Name:"+this.name);
		System.out.println("Roll No:"+this.rollno);
		System.out.println("marks m1:"+this.m1);
		System.out.println("marks m2:"+this.m2);
		System.out.println("Average:"+this.avg);
	}
	
	public Student(int rollno,String name,int m1,int m2) {
		this.rollno=rollno;
		this.name=name;
		this.m1=m1;
		this.m2=m2;
		this.avg=(m1+m2)/2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s=new Student(10,"shubham",45,76);
		s.display();
		

	}

}
