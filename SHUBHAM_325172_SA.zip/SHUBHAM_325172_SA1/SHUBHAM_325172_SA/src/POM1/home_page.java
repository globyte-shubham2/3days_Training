package POM1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class home_page {

	
	WebDriver dr;
	
	home_page(WebDriver dr){
		
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	String base_xp="//div[@class='inventory_item'][";
	By xp;
	
	public void add_to_cart(int n) {
		xp=By.xpath(base_xp+n+"]//button");
		dr.findElement(xp).click();
		
	}
	
	public void click_cart() {
		dr.findElement(By.xpath("//a[@class='shopping_cart_link fa-layers fa-fw']")).click();
	}
	
}
