package Assignment_27_oct_2019;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class productReadWrite {
	ArrayList<product> p_data;
	public void read_excel() {
		p_data = new ArrayList<product>();
		try {
			File f = new File("C:\\Users\\shubham.arora2\\Book4.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			int first = sh.getFirstRowNum();
			int end = sh.getLastRowNum();
			for(int i=1;i<end-first+1;i++) {
				product p = new product();
				XSSFRow rw = sh.getRow(i);
				
				XSSFCell c1 = rw.getCell(0);
				p.p_id = (int)c1.getNumericCellValue();
				XSSFCell c2 = rw.getCell(1);
				p.p_name = c2.getStringCellValue();
				XSSFCell c3 = rw.getCell(2);
				p.unit_price = (int)c3.getNumericCellValue();
				XSSFCell c4 = rw.getCell(3);
				p.units_purchased = (int)c4.getNumericCellValue();
				p.price = p.unit_price * p.units_purchased;
				if(p.price < 25000) {
					p.grade = "GradeA";
				}else {
					p.grade = "GradeB";
				}
			p_data.add(p);
				
					
			}
				
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void write_excel() {
		
		try {
			File f = new File("C:\\Users\\shubham.arora2\\Book4.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			int first = sh.getFirstRowNum();
			int last = sh.getLastRowNum();
			int row=1;
			for(product p:p_data) {
				XSSFRow rw = sh.getRow(row);
				XSSFCell c1 = rw.createCell(4);
				c1.setCellValue(p.price);
				XSSFCell c2 = rw.createCell(5);
				c2.setCellValue(p.grade);
				row++;
			}
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
