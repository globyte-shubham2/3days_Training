package DAY3;

public class a {
	int abc;
	public void show1() {
		System.out.println(this.abc);
	}

}
