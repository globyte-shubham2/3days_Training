package DAY2;
import java.util.*;
public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Please enter a number");
		int num=in.nextInt();	
		String op="";
		int n=num;
		while(n != 0 ) {
			int r=n%10;
			switch(r) {
			case 0:op="zero";break;
			case 1:op="one";break;
			case 2:op="two";break;
			case 3:op="three";break;
			case 4:op="four";break;
			case 5:op="five";break;
			case 6:op="six";break;
			case 7:op="seven";break;
			case 8:op="eight";break;
			case 9:op="nine";break;
			default:System.out.println(n);
			}
			System.out.println(op);
			n=n/10;
		}
		
	}

}
