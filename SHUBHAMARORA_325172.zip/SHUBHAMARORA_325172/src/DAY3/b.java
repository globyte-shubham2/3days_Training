package DAY3;

public class b extends a {
	int xyz;
	public void show2() {
		System.out.println(this.xyz);
	}

}
