package DAY6;

import java.util.ArrayList;

import DAY3.student;

public class pgm3 {

		
		ArrayList<student> std_al = new ArrayList<student>();
        
		public void create_al() {
        	student s1=new student("shubham",101,78,99);
        	s1.average();
        	student s2=new student("arora",103,88,67);
        	s2.average();
        	std_al.add(s1);
        	std_al.add(s2);
        	
        }
		
		public void display() {
			for(student s:std_al) {
				System.out.println("Name:"+s.name+"  Rollno."+s.rollno+"  m1:"+s.m1+"  m2:"+s.m2+"  average:"+s.avg);
			}
		}
		
	public static void main(String args[]) {
		pgm3 pg=new pgm3();
		pg.create_al();
		pg.display();
	}

}
