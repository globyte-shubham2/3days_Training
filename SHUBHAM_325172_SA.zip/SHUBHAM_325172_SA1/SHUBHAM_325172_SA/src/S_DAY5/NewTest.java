package S_DAY5;

import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void f() {
	  System.out.println("In test f");
  }
  @Test
  public void f1() {
	  System.out.println("In test f1");
  }
  @Test
  public void f2() {
	  System.out.println("In test f2");
  }
}
