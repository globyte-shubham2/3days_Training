package DAY4;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm4 pg=new pgm4();
		int sum = pg.add(5,10);
		System.out.println("first sum = "+ sum);
		float s= pg.add(2,3.0f,5.0f);
		System.out.println("Second sum is: "+s);
				

	}

}
