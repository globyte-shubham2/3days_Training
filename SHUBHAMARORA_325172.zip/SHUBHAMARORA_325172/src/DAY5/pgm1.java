package DAY5;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int a=90;
			System.out.println(a/0);
			int b[]= {2,3,4};
			System.out.println(b[3]);								
		}
		catch(Exception e) {
			System.out.println(e);
		}
		finally{
		    
			System.out.println("shubham");
		}
		

	}

}
