package S_DAY5;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;

public class NewTest4 {
	
	@BeforeClass
	public void start() {
		System.out.println("I came to the cricket stadium");
	}
	
	@AfterClass
	public void end() {
		System.out.println("Now I am back home");
	}
	
	@BeforeMethod
	public void func() {
		System.out.println("Hello");
	}
	
	@Test
	public void func1() {
		System.out.println("I met Mr.Dhoni");
	}
	
	@AfterMethod
	public void func2() {
		System.out.println("Bye");

	}
	
	@Test
	public void func3() {
		System.out.println("I had my lunch with Mr. Virat Kohli");

	}
	
	@Test
	public void func4() {
		System.out.println("I took a pic with Mr. Rohit Sharma");

	}
	

}
