package S_DAY7;

public class basic_testlogin extends excel_io_arr{
	
	public static String kw,xp,td;
	
	public static void login() {
		WebElements we = new WebElements();
		int row=0;
		for(String s[]:testdata) {
			kw = s[0];
			xp = s[1];
			td = s[2];
			switch(kw) {
			case "launchchrome":we.launchChrome(td);
			break;
			case "click_link":we.clickLink(xp);
			break;
			case "click_radio":we.clickRadio(xp);
			break;
			case "enter_txt":we.enterText(xp,td);
			break;
			case "click_btn":we.clickButton(xp);
			break;
			case "verify":we.verify(xp,td,row);
			break;
			case "close_browser":we.closeBrowser();
			break;			
			}
			row++;
		}
	}
	public static void main(String args[]) {
		testdata = new String[18][3];
		for(int i=1;i<19;i++) {
			rowno = i;
			get_test_data();
		}
		for(String[] s:testdata) {
			System.out.println(s[0]+"  "+s[1]+"  "+s[2]);
		}
		
		login();
	}

}
