package S_DAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginReadWrite {
	
	public static LoginData readExcel() {
		LoginData ld = new LoginData();
		try {
			
			File f = new File("login.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb  = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow rw = sh.getRow(1);
			XSSFCell c = rw.getCell(0);
			ld.uid = c.getStringCellValue();
			XSSFCell c1 = rw.getCell(1);
			ld.pass = c1.getStringCellValue();
			XSSFCell c2 = rw.getCell(2);
			ld.exp = c2.getStringCellValue();
			
			
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return ld;
	}
	
	public static void login(LoginData l) {
	       System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
	       WebDriver dr = new ChromeDriver();
	       dr.get("http://demowebshop.tricentis.com/");
	       
	       dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	       dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(l.uid);
	       dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(l.pass);
	       dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	       
	       String str = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	       if(str.equals(l.uid))
	    	   excelWrite(true);
	       else
	    	   excelWrite(false);
	}
	
	public static void excelWrite(boolean br) {
		if(br) {
			try {
				
				File f = new File("login.xlsx");
				FileInputStream fis = new FileInputStream(f);
				XSSFWorkbook wb  = new XSSFWorkbook(fis);
				XSSFSheet sh = wb.getSheet("Sheet1");
				XSSFRow rw = sh.getRow(1);
				XSSFCell c = rw.createCell(3);
				c.setCellValue("success");
				XSSFCell c1 = rw.createCell(4);
				c1.setCellValue("pass");
				FileOutputStream fos = new FileOutputStream(f);
				wb.write(fos);
				
				
				
				
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
	}

	public static void main(String args[]) {
		LoginData data = readExcel();
		login(data);
	}

	/* Implicit webpage wait */
//	dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	
	/* Explicit wait in webpage  */	
//	WebDriverWait wt = new WebDriverWait(dr,10);
//	wt.until(ExpectedConditions.elementToBeClickable(By.xpath("dhsu")));� 
//	wt.until(ExpectedConditions.titileContains("Facebook"));
//	dr.findElement(By.xpath()).click();�

	
	
}
