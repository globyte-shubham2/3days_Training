package Assignment_27_oct_2019;

public class productMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		productReadWrite p = new productReadWrite();
		p.read_excel();
		p.write_excel();

	}

}
