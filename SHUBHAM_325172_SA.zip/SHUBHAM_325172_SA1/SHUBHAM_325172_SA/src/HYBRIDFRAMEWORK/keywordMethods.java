package HYBRIDFRAMEWORK;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

public class keywordMethods {
	WebDriver dr;
	public void launchChrome(String url) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		dr = new ChromeDriver();
		dr.get(url);
	}
	
	public void clickLink(String url) {
		dr.findElement(By.xpath(url)).click();
	}
	
	public void enterText(String url,String data) {
		dr.findElement(By.xpath(url)).sendKeys(data);		
	}
	
	public void clickButton(String url) {
		dr.findElement(By.xpath(url)).click();
	}
	
	public void verify(String url,String data) {
		String str = dr.findElement(By.xpath(url)).getText();
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(str, data);
		sa.assertAll();
	}

}
