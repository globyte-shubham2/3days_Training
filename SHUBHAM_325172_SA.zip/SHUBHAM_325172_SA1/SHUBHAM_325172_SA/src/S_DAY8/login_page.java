package S_DAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class login_page 
{
	
	WebDriver dr=null;
	
	public login_page(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr,this);
	}
	
	public void enter_mail(String xp,String id) {
		dr.findElement(By.xpath(xp)).sendKeys(id);
	}
	
	public void enter_password(String xp,String pass) {
		dr.findElement(By.xpath(xp)).sendKeys(pass);
	}
	
	public void click_login() {
		dr.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]")).click();
	}
	
	public void do_login(String uid,String pass) {
		enter_mail("//*[@id=\"user-name\"]",uid);
		enter_password("//*[@id=\"password\"]",pass);
		click_login();
	}
	

}
