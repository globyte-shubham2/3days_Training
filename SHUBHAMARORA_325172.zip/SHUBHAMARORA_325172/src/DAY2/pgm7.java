package DAY2;
import java.util.*;
public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=in.nextInt();
		int sum=0;
		while(num!=0) {
			int r=num%10;
			if(r>5)
				sum+=r;
			num/=10;
		}
		System.out.println(sum);

	}

}
