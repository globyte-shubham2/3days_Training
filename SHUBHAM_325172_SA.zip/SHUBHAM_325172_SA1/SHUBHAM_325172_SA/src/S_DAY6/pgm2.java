package S_DAY6;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class pgm2 {
  @Test
  public void a() {
	  String s1="noida",s2="noida";
	  Assert.assertEquals(s1, s2);
	  System.out.println("In a");
  }
  @Test
  public void b() {
	  String s1="noida",s2="noida1";
	  SoftAssert sa = new  SoftAssert();
	  sa.assertEquals(s1, s2);
	  System.out.println("In b");
	  sa.assertAll(); // it is mandatory to include assertAll() in case of SoftAssert
  }
  @Test
  public void c() {
	  String s1="noida",s2="noida1";
	  Assert.assertEquals(s1, s2);
	  System.out.println("In c");
  }
}
