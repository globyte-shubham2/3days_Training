package DAY1;
import java.util.*;
public class pgm10 {
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		char ch = 'a';
		if(ch=='a' || ch=='A' || ch=='e' || ch=='E' || ch=='i' || ch=='I' || ch=='o' || ch=='O' || ch=='u' || ch=='U' )
			System.out.println("vowel");
		ch='b';
		if(ch=='a' || ch=='A' || ch=='e' || ch=='E' || ch=='i' || ch=='I' || ch=='o' || ch=='O' || ch=='u' || ch=='U' ) {
			
		}
		else {
			System.out.println("Not a vowel");
		}
	}

}
