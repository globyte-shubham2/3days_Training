package S_DAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_io_arr {
	
	public static String testdata[][];
	public static int rowno,colno;
	
	public static void get_test_data() {
		try {
			File f = new File("registerKWF.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow  rw = sh.getRow(rowno);
			XSSFCell c1 = rw.getCell(3);
			testdata[rowno-1][0] = c1.getStringCellValue();
			XSSFCell c2 = rw.getCell(4);
			testdata[rowno-1][1] = c2.getStringCellValue();
			XSSFCell c3 = rw.getCell(5);
			testdata[rowno-1][2] = c3.getStringCellValue();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void writeData(String str,int row) {
		try {
			File f = new File("registerKWF.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow  rw = sh.getRow(row);
			XSSFCell c1 = rw.createCell(6);
			c1.setCellValue(str);
			FileOutputStream fos = new FileOutputStream(f);
			wb.write(fos);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
//	public static void main(String args[]) {
//		testdata = new String[11][3];
//		for(int i=1;i<12;i++) {
//			rowno = i;
//			get_test_data();
//		}
//		for(String[] s:testdata) {
//			System.out.println(s[0]+"  "+s[1]+"  "+s[2]);
//		}
//	}

}
