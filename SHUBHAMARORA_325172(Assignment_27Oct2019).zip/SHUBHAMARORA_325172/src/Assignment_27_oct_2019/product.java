package Assignment_27_oct_2019;

public class product {
	int p_id;
	String p_name;
	int unit_price;
	int units_purchased;
	int price;
	String grade;

}
