package S_DAY6;

import org.testng.annotations.Test;

public class pgm1 {
  @Test(priority=8)
  public void a() {
	  System.out.println("In a");
  }
  @Test(priority=3)
  public void b() {
	  System.out.println("In b");
  }
  @Test(priority=0)
  public void c() {
	  System.out.println("In c");
  }
}
