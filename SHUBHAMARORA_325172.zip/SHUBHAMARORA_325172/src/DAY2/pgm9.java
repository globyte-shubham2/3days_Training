package DAY2;

public class pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		    int i=5;
			for(int j=4;j<=12;j+=2) {
				System.out.print(i+" * "+j+" = "+i*j);
				i++;
				System.out.println();
			}
			
		

	}

}

