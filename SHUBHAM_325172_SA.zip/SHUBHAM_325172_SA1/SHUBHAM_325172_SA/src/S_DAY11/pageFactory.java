package S_DAY11;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class pageFactory {
	
	@FindBy(xpath="//input[@class='email']")
	WebElement emailId;
	
	@FindBy(xpath="//input[@class='password']")
	WebElement password;
	
	@FindBy(xpath="//input[@value='Log in']")
	WebElement btn;
	
	WebDriver dr;
	
	public pageFactory() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
	    dr = new ChromeDriver();
	    PageFactory.initElements(dr, this);
	   
	}
	
	public void lauchchrome() {
		dr.get("http://demowebshop.tricentis.com/login");
	}
	
	public void set_uid() {
		emailId.sendKeys("shubham.1510150@kiet.edu");
	}
	
	public void set_pass() {
		password.sendKeys("p0o9i8u7y6");
	}
	
	public void click_btn() {
		btn.click();
	}
	
	public static void main(String args[]) {
		pageFactory pf = new pageFactory();
		pf.lauchchrome();
		pf.set_uid();
		pf.set_pass();
		pf.click_btn();
		
	}

}
