package DAY4;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Hey there i am using whatsapp";
		int index = str.lastIndexOf(" ");
		str=str+" ";System.out.println(str);
		String words[]=new String[20];
	    int findex,lindex,i=0,start=0;
	    findex=str.indexOf(" ");
	    lindex=str.lastIndexOf(" ");
	    while(findex != lindex) {
	    	words[i]=str.substring(start, findex);
	    	start=findex+1;
	    	findex=str.indexOf(" ", start);
	    	System.out.println(words[i]);
	    	i+=1;
	    	
	    }

	    words[i]=str.substring(index+1,lindex);
	    
	    System.out.println(words[i]);
	    
	    
	  
	}

}
