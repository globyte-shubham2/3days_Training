package main.java;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class placeorder {
	WebDriver dr;
	public placeorder(WebDriver dr) {
		this.dr=dr;
	}
public void placeorder1() {
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div[2]/div/div[1]/div[1]/div[3]/div/form/button")).click();
}
  public void delivery() {
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	dr.findElement(By.xpath("//*[@id=\"to-payment\"]/button")).click();
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div[1]/div[4]/div/div/div[2]/div/label[4]")).click();
	try {
		Thread.sleep(50000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div[1]/div[4]/div/div/div[2]/div/label[4]/div[2]/div/div/div[2]/form/button")).click();
}

}
