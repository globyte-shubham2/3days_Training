package S_DAY7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElements {
	WebDriver dr;
	public void launchChrome(String url) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr = new ChromeDriver();
		dr.get(url);
	}
	
	public void clickLink(String xp) {
		dr.findElement(By.xpath(xp)).click();
	}
	
	public void clickRadio(String xp) {
		dr.findElement(By.xpath(xp)).click();
	}
	
	public void enterText(String xp,String td) {
		dr.findElement(By.xpath(xp)).sendKeys(td);
	}
	
	public void clickButton(String xp) {
		dr.findElement(By.xpath(xp)).click();
	}
	
	public void verify(String xp,String td,int row) {
		excel_io_arr ar = new excel_io_arr();
		String str = dr.findElement(By.xpath(xp)).getText();
		if(str.equals(td))
		    ar.writeData("PASS",row+1);
		else
			ar.writeData("FAIL",row+1);		
	}
	
	public void closeBrowser() {
		dr.close();
	}
	

}
