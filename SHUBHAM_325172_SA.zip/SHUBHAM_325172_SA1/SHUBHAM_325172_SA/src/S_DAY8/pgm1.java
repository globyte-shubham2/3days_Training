package S_DAY8;

import org.apache.log4j.Logger;

public class pgm1 {
	
	public static void main(String args[]) {
		Logger log = Logger.getLogger("shubham");
		log.debug("Error happened");
	}

}
