package S_DAY4;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {
	
	public static void main(String args[]) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://naukri.com");
		
		String hnd = dr.getWindowHandle();
		String str = dr.getTitle();
		System.out.println(str);
		System.out.println(hnd);
		for(String handle:dr.getWindowHandles()) {
			dr.switchTo().window(handle);
			String title = dr.getTitle();
			System.out.println(title);
		}
		System.out.println(dr.getTitle());
	}

}
